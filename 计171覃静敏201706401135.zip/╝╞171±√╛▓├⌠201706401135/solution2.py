n,m = [int(x) for x in input().split()]
#n变量数 m约束数
a = [float(x) for x in input().split()]#价值
x_data=[]#属性
for i in range(m):
    t = [int(x) for x in input().split()]
    x_data.append(t)

things = len(x_data[0])
y = [int(x) for x in input().split()]#约束条件

# print(x_data)


def valid(ans):
    for i in range(m):
        constraintSum = 0
        for count_index in range(len(ans)):
            try:
                constraintSum += (ans[count_index] * x_data[i][count_index])
            except Exception as e:
                print("index:",count_index," i:",i)
        if constraintSum >= y[i]:
            return False
    return True

answers = [[]]

for i in range(n):
    cr = []
    for answer in answers:

        temp = answer + [1]
        answer += [0]
        if valid(temp):
            cr += [temp]
    answers += cr

values = []
for answer in answers:
    # print(answer)
    value = 0
    for i in range(len(answer)):
        value += (answer[i]*a[i])

    values.append(value)

print("%.2f" % (max(values)))
